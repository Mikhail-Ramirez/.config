## waybar-config

A minimal black 


## Order 
- Speaker > Mic > Wifi > Brightness > CPU > Memory > Battery > Time (12 hour formate)
  ![20240504_18h18m02s_grim](https://github.com/kamlendras/waybar-config/assets/96082996/71c6f642-5ece-4a33-b962-960f217b6849)

